package datastructure;

public class Emergencycall {
	int id;
	int x,y;
	String type;
	int severity;
	long timestamp;
	
    public Emergencycall(int id, int x, int y, String type, int severity) {
    	this.id=id;
    	this.x=x;
    	this.y=y;
    	this.type=type;
    	this.severity=severity;
    	this.timestamp=System.currentTimeMillis();
    	
   
    }
}
