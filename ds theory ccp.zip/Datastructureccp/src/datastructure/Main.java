
package datastructure;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        EmergencyDispatch ED = new EmergencyDispatch();

        //Add Units 
        System.out.print("How many units do you want to add? ");
        int numUnits = sc.nextInt();

        for (int i = 0; i < numUnits; i++) {
            System.out.println("Enter details for Unit " + (i + 1) + " (ID Type x y): ");
            int id = sc.nextInt();
            String type = sc.next();
            int x = sc.nextInt();
            int y = sc.nextInt();

            ED.addUnit(new EmergencyUnit(id, type, x, y));
        }

        // Add Calls 
        System.out.print("How many calls do you want to add? ");
        int numCalls = sc.nextInt();

        for (int i = 0; i < numCalls; i++) {
            System.out.println("Enter details for Call " + (i + 1) + " (ID x y Type Severity): ");
            int id = sc.nextInt();
            int x = sc.nextInt();
            int y = sc.nextInt();
            String type = sc.next();
            int severity = sc.nextInt();

            ED.addcalll(new Emergencycall(id, x, y, type, severity));
        }

        // Dispatch Calls 
        System.out.println("\nDispatching calls...");
        for (int i = 0; i < numCalls; i++) {
            ED.Dispatch();
        }

        sc.close();
    }
}

