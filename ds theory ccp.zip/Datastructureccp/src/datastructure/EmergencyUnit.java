package datastructure;

public class EmergencyUnit {
	int id;
	String type;
	int x,y;
    boolean available;
  
    public EmergencyUnit(int id, String type, int x, int y) {
    	this.id=id;
    	this.type=type;
    	this.x=x;
    	this.y=y;
    	this.available=true;
    	
    }


}
