package datastructure;

import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.util.PriorityQueue;

public class EmergencyDispatch {
    private PriorityQueue<Emergencycall> callQueue;    // Priority Queue for calls (Sorting)
    private HashMap<Integer, EmergencyUnit> unitMap;  // HashMap for fast unit lookup
    private HashMap<String, List<EmergencyUnit>> unitsByType; // Units grouped by type
    private List<Emergencycall> completedCalls;       // Log of completed calls

    public EmergencyDispatch() {
        callQueue = new PriorityQueue<>((a, b) -> {
            if (a.severity != b.severity)
                return a.severity - b.severity;
            return Long.compare(a.timestamp, b.timestamp);
        });
    
        unitMap = new HashMap<>();
        unitsByType = new HashMap<>();
        completedCalls = new ArrayList<>();
    }
    public void addcalll(Emergencycall call) {//   Add Emergency Call
    	callQueue.add(call);
        System.out.println(" Call Added | ID: " + call.id + " | Type: " + call.type +" | Severity: " + call.severity);
  
    }
    public void addUnit(EmergencyUnit unit) {// Add Emergency Unit
        unitMap.put(unit.id, unit);
        unitsByType.putIfAbsent(unit.type, new ArrayList<>());
        unitsByType.get(unit.type).add(unit);
    }
public void Dispatch(){//Dispatch Highest Priority Call
	if(callQueue.isEmpty()) {
		System.out.println("no pending calls");
		return;
		
	}
	Emergencycall call=callQueue.poll();
	List<EmergencyUnit> units = unitsByType.get(call.type);
	
	if(units==null) {
		System.out.println("no units for types"+call.type);
		callQueue.add(call);
		return;
		
	}
EmergencyUnit nearst=null;
double minDistance = Double.MAX_VALUE;
for (EmergencyUnit unit : units) {
    if (unit.available) {
        double distance = calculateDistance(unit, call);
        if (distance < minDistance) {
            minDistance = distance;
            nearst = unit;
        }	
	
}

}

if (nearst != null) {
    nearst.available = false;
    completedCalls.add(call);
    System.out.println("DISPATCHED");
    System.out.println("Call ID: " + call.id +" → Unit ID: " + nearst.id +" | Distance: " + minDistance);
    nearst.available = true;

} else {
    System.out.println(" No available unit. Call re-queued.");
    callQueue.add(call);
}
}
//Distance Calculation

private double calculateDistance(EmergencyUnit unit, Emergencycall call) {
return Math.sqrt(
        Math.pow(unit.x - call.x, 2) +
        Math.pow(unit.y - call.y, 2)
);
}
}



